## Question 2: In which movie was the plaintext used?

Answer : Fight Club (1999)

## Question 3: Is it more secure? If so, is it considered fully secure?

Answer: While it is a bit more secure than just caesar cipher, it is by no means fully secure since it just runs the same function twice.

## Question 4: What can you generally observe by using this double encryption?

Answer: Double encryption makes the ciphertext more complex and harder to crack but it is still vulnerable to analysis. Double cipher of keys 13 and 9 is equal to single shift cipher of key 13+9 = 22. So in essence its boosting the security by much.

## Question 5: Compared to the original Caesar cipher, is there any performance drop-off?

Answer: The performance drop is minimal since the 2 shifts basically collaspe to one shift of added keys, so computationally there is little to no change. 