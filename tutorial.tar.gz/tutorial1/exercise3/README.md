## Question 1: Encrypt aliceandbob with a = 7 and b = 5

Answer: 
y = (ax + b) mod 26
FEJTHFSAMZM

## Question 2: How secure is the Affine Cipher compraed to the original caesar cipher?

Answer: Caesar cipher has keyspace of 25 whereas affince cipher has two keys, there are 12 possible values for a and 26 possible values of b. This makes the keyspace of size 12 * 26 = 312 possible keys. This is more than caesar cipher but can still be brute forced.
Doing frequency analysis on both ciphers is still possible because even though affince has two functions, multiplication and addition it is still monoalphabetic substitution cipher meaning 'a' would always map to 'd' or some fixed letter for specific keys.

## Question 3: Decrypt MDS CTMZU MDS CTMZU with a = 11 and b = 2

Answer: 
x = (c * (x-b)) mod 26
ITS ALIVE ITS ALIVE